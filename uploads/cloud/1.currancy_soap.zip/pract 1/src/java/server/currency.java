package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "currency")
public class currency {

    /**
     * Web service operation to convert USD to INR
     */
    @WebMethod(operationName = "convertUSDToINR")
    public String convertUSDToINR(@WebParam(name = "usd") double usd) {
          return usd + " USD = " + (usd * 83.0) + " INR";
    }
}
