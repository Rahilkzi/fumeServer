/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypkg;

import java.io.*;
import javax.jws.Oneway;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.ws.soap.MTOM;


@MTOM(enabled = true, threshold = 60000)
@WebService(serviceName = "ImageWS")
public class ImageWS {
    
    @WebMethod(operationName = "upload")
    @Oneway
    public void upload(@WebParam(name = "Filename") String Filename, @WebParam(name = "ImageBytes") byte[] ImageBytes) {
                String filePath = "C:/Picture/upload/" + Filename;
                
                try{
                    FileOutputStream fos = new FileOutputStream(filePath);
                    BufferedOutputStream bos = new BufferedOutputStream(fos);
                    bos.close();
                    System.out.println("Received file: " + filePath);

                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
    }
    @WebMethod(operationName = "download")
    public byte[] download(@WebParam(name = "Filename") String Filename) {
        String filePath = "C:/Picture/upload/" + Filename;
        System.out.println("Sending file: " + filePath);
        try{
            File file = new File(filePath);
            FileInputStream fis = new FileInputStream(file);
            BufferedInputStream bis = new BufferedInputStream(fis);
            byte[] fileBytes = new byte[(int)file.length()];
            bis.read(fileBytes);
            bis.close();
            return fileBytes;
        }
        catch(Exception ex){
            ex.printStackTrace();
            return null;
            
        }


}
}

