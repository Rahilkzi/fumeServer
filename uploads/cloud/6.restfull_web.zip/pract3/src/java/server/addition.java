/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Lenovo
 */
@WebService(serviceName = "addition")
public class addition {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "addition")
    public addition(@WebParam(name = "n1") int n1, @WebParam(name = "n2") int n2) {
        int sum = n1 +n2;;
        return sum;
    }

    /**
     * This is a sample web service operation
     */
  
}
